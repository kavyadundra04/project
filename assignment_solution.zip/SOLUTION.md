# Collections assignment — independent solution

## Executive memo (two-page equivalent)

**Decision:** Do not certify the unqualified “11% month-on-month improvement” claim. It is numerically reproducible for **March versus February**, using successful-payment value after payment-ID deduplication (+11.0319%). It is not the latest complete-month result: **July versus June is +6.6545%**. No report month or original reporting query was supplied. More importantly, these are provisional transaction-value comparisons, not evidence of improved collections effectiveness.

The supplied payment data covers January 1–August 8, 2026, not twelve months. August is partial and must not be compared with full July. February has 28 days versus March's 31: March's per-calendar-day change is only **+0.287%**. July has 31 days versus June's 30: July's daily-value change is **+3.214%**. Day adjustment is descriptive; it does not control for holidays, due dates, portfolio exposure or seasonality. January and July provisional totals are almost identical (+0.007%). There is no convincing sustained upward trend in these totals.

**Fact:** payment-ID deduplication reduces the raw SUCCESS total. **Fact:** reference collisions remain after this cleaning. **Fact:** 25,499 of 25,500 payment rows disagree with the account master on borrower identity. Every one of the 1,000 agent IDs maps to multiple employee codes. All 35,000 dispositions disagree with their linked call's account. These are critical relational failures, not small missing-value problems. This data cannot establish reliable agent, borrower, RPC, causal channel or campaign performance.

**Why:** calendar length explains much of March's reported-looking uplift arithmetically. Duplicate ingestion inflates payment totals; ambiguous references and identity conflicts prevent cash certification. Portfolio-mix improvement, targeting uplift and vendor improvement remain hypotheses. Snapshot DPD/status cannot reconstruct historical eligibility. The tables do not establish that an actual midyear targeting intervention occurred, nor provide an untreated comparable population.

**Action:** if leadership must select one investment area, select **better borrower targeting**, conditional on data repair and a randomized pilot. This is a testable strategic choice, not a proven highest-ROI ranking. Do not commit the entire ₹10 Cr based on this file. Assign a ₹10 Cr ceiling to this area, initially release an assumed ₹0.5 Cr pilot budget, and release the remainder only after positive incremental net economics and compliant contact outcomes.

**Financial impact:** no measured incremental recovery or defensible causal confidence interval is identifiable. For a transparent planning scenario only: ₹100 Cr eligible opening exposure × 15 percentage-point incremental recovery = ₹15 Cr incremental gross cash. At an assumed 80% retained contribution, benefit is ₹12 Cr, net benefit ₹2 Cr, ROI 20% against ₹10 Cr all-in cost. Break-even is ₹12.5 Cr incremental cash, or 12.5 percentage points on that exposure. At 100% retained benefit, break-even cash is ₹10 Cr. If the platform retains only 20%, break-even cash is ₹50 Cr. Do not confuse client collections with platform revenue.

Illustrative downside/base/upside incremental cash of ₹5/15/25 Cr at 80% retention gives ROI **−60%/+20%/+100%**. This is a scenario range, **not a statistical confidence interval or forecast**. Eligible exposure, achievable uplift, retention, capacity, cost and time horizon all require validation. Pilot over a fixed 90-day outcome horizon; set a harm-based stop rule and a prespecified economic gate. The calendar break-even date cannot be estimated without a cash-flow ramp.

## 1. What actually happened?

Amounts below are SUCCESS event values, in ₹ Cr (₹10,000,000), not bank-reconciled receipts. IDs with conflicting payloads receive a deterministic representative solely for provisional sensitivity analysis, never financial certification.

|Month|Raw SUCCESS|Payment-ID deduplicated|Reference-safe candidate|Provisional MoM|
|---|---:|---:|---:|---:|
|Jan|19.1133|18.7229|17.9775|—|
|Feb|17.4097|17.0142|16.4013|−9.1261%|
|Mar|19.3233|18.8912|18.1335|+11.0319%|
|Apr|17.8427|17.5138|16.7979|−7.2914%|
|May|18.7048|18.4250|17.6619|+5.2029%|
|Jun|17.8724|17.5560|16.7902|−4.7167%|
|Jul|19.0279|18.7242|18.2230|+6.6545%|
|Aug 1–8|4.8543|4.7110|4.5237|not comparable|

The reference-safe series excludes missing references, conflicting payment IDs and provider/reference collisions. It is **not a lower confidence bound**: excluded events may be real, and retained events are not bank verified. March/February and July/June results depend on this policy; see the exact CSVs. Raw July/June growth is approximately 6.465%, versus 6.655% after ID cleaning. Do not describe all repeated references as duplicates: unrelated IDs can collide, especially across providers.

## 2. Golden layer and data-quality report

Source of truth is unresolved: treat accounts as a candidate account registry and payments as a candidate transaction feed. Do not overwrite event borrower IDs with master IDs and call this repaired truth. Preserve both and publish mismatch flags. Account-level arithmetic is explicitly conditional on event account IDs being correct.

|Issue and detection|Measured finding|Treatment / business implication|
|---|---|---|
|Payment exact-row and key audit|25,500 raw rows → 25,014 distinct payloads → 25,000 payment IDs; 14 IDs have conflicting payloads|486 exact duplicates removed; conflicting IDs quarantined from reference-safe layer; provisional representative is arbitrary, disclosed|
|Reference audit at provider + reference grain|368 representative IDs missing reference; 587 non-ID-conflict representatives share a provider/reference|No fuzzy deletion; quarantine and request provider ledger. A reference alone is not globally unique|
|Reference-safe candidate|24,031 IDs across all statuses; only positive SUCCESS enters golden_payments|Status eligibility applied after identity-quality checks; see payment_audit.csv for every ID|
|Borrower consistency|25,499/25,500 payments; 91,342/91,350 calls mismatch account master|Borrower/geography/language results blocked pending authoritative crosswalk|
|Linked call consistency|119,992/120,000 attempts mismatch linked call account; 35,000/35,000 dispositions mismatch|Do not compute RPC or attempt funnels by blindly joining call_id|
|Agent resolution|1,000/1,000 agent IDs map to multiple employee codes|No reliable agent or tenure ranking; names and phone numbers are not identity keys|
|Borrower master|8,518 borrower IDs have multiple distinct payload rows|No authoritative latest-wins without trusted update/version semantics|
|Campaign validity|72,580 unique calls fall outside campaign start/end timestamps|Comparisons use source-local timestamp strings and are diagnostic, not timezone-certified counts; near-boundary flags need normalized recheck|
|Historical validity|30,191 history rows recorded before their event timestamp|Investigate clock semantics; no unvalidated historical population reconstruction|
|Coverage|Jan–Aug 8, not twelve months|No year-long trend or annual seasonality conclusion|

**Timestamps:** calls have row-level UTC/Kolkata/Dubai labels. Parse locally, attach the named zone, store UTC and derive Asia/Kolkata reporting dates. Their offsets are 0/+5:30/+4. Sessions likewise use row zones. Payments and most other event tables lack a timezone. The supplied pipeline retains their raw month and assumes IST only for exploratory attribution. Payment month allocation is unresolved, especially near midnight; obtain source contracts before certification. Do not infer timezone from provider master when event-specific metadata disagrees. Never discard raw timestamps.

**Payments:** retain FAILED/PENDING for reconciliation but exclude them from SUCCESS cash. REVERSED values are reported separately. Do not subtract every reversal row from successes without matching its original transaction and confirming whether the source represents state transitions or independent ledger entries. Missing source ingestion timestamps prevent reproducible as-known-at reporting and lateness measurement.

**Missing data:** do not impute payment references, language, client, historical exposure, staffing cost or missing balances. Unknown is a category in descriptive analysis; quarantine affects certification, not silent row deletion. No exact-row deduplication across distinct business keys. Daily targeting remains inclusive of queued/skipped/expired records; contacted-only denominators would select outcomes.

## 3. Metric contract

|Metric|Independent definition and availability|
|---|---|
|Recovery rate|Net settled ledger cash against a frozen eligible cohort / opening collectible balance of that cohort. Align numerator debts and window; cap/flag overpayments. Historical opening balances and reconciled ledger absent: unavailable|
|Recovery per account|Same cohort cash / all eligible accounts, including zero outcomes. Provided proxy: SUCCESS value / fixed 30,000 registered accounts, not recovery rate|
|Contact rate|Distinct eligible attempted accounts with validated human connection / all distinct attempted accounts. Also report attempted / eligible coverage. ANSWERED is only a technical proxy, not right-party contact|
|RPC|Verified borrower/authorized-party conversations / validated human contacts, plus RPC / eligible-account coverage. Versioned disposition taxonomy needed; unavailable|
|PTP rate|Distinct RPC accounts making a valid promise / distinct RPC accounts. Report promise count separately; broken call joins prevent calculation|
|PTP kept rate|Mature promises with allocated settled payments meeting promised amount by agreed due date + fixed grace / all mature promises, including broken; exclude not-yet-due. Allocate each rupee once, earliest due first. Source KEPT label alone insufficient|
|Recovery per agent-hour|Human-channel incremental recovery / deduplicated non-overlapping paid productive hours. Separate total account cash proxy from incremental credit. Ambiguous identities, sparse sessions and no pay contract block certification|
|Cost per ₹|All-in attributable economic cost / incremental recovered cash, also report gross cost/cash separately. Cost ledger absent|
|Channel conversion|Randomized assigned accounts with settled payment within fixed horizon / all assigned eligible accounts, intention-to-treat. Observational message delivery/read rates are separate operational metrics|

Vendor codes need a vendor × schema × effective-date dictionary with test fixtures. No dated mapping-change evidence is supplied. PTP and PROMISE_TO_PAY may be candidate synonyms, not a verified mapping. A code/version difference alone does not prove a vendor migration.

## 4. Driver investigation and evidence grading

**Fact:** March's aggregate value rises 11.03%, but daily value rises 0.29%. This is an arithmetic decomposition, not causal proof about operations. **Fact:** exact duplicates exist. **Hypothesis:** portfolio or targeting explains a true uplift; unsupported here.

|Required dimension|Investigation and conclusion|
|---|---|
|Portfolio / DPD / borrower segment|Export descriptive monthly SUCCESS by loan_type, snapshot DPD and risk_segment. The fixed-snapshot mix file holds segment weights fixed. Because every account is in a fixed registry and there is no historical exposure panel, this is a proxy, not valid historical mix adjustment|
|Client|No client key or client exposure table; cannot assess|
|Geography / language|Borrower city/state exists but borrower resolution fails; language absent. Do not publish geographic attribution through ambiguous joins|
|Agent / tenure|Agent identity is many-to-many; joined_at is not an authoritative employment history. No rankings or staffing uplift estimate|
|Campaign / channel|Campaign dates conflict with calls and selection is observational. Temporal channel sensitivity exported at 1/3/7/14 days; association only. No valid ROI ranking|
|Vendor|Compare technical statuses only after event-key and timezone validation; current vendor schema is not a historical change log. No migration effect identified|
|Calling time|Normalize labeled calls to IST before bins; raw hours mix three zones. Unknown payment zone and confounding prevent causal best-hour conclusion|
|Attempt frequency|Attempt count and linked-call account conflict; high attempts can reflect difficult accounts, not cause poor recovery. No optimal attempt cap estimated|

**Mix/cohort effects:** build account-month opening exposures with immutable vintage, client, DPD and risk measured before targeting. Standardize to a fixed base distribution; report strata with common support and coverage. The supplied snapshot cannot do this reliably. **Selection bias:** contacted/read/reached accounts are post-treatment subsets; use all assigned accounts. **Survivorship:** current PAID/CLOSED status must not remove historical accounts. **Simpson's paradox:** compare aggregate and within-stratum trends after reconstruction; no demonstrated reversal is established here. **Attribution-window bias:** exported last-touch sensitivities show how credit changes with the chosen window; never sum multi-touch credits beyond payment total. **Time series:** incomplete August and month length matter; seven full months cannot support credible annual seasonal adjustment. No significance claim or causal CI is justified.

## 5. Counterfactual targeting design

The assignment asks us to assume a midyear strategy change. That is a scenario, not an observed intervention date in these files. Define treatment as eligible accounts assigned to the new strategy, not accounts successfully contacted. Control must be contemporaneous eligible accounts assigned to the old strategy. Obtain rollout logs, exact date, targeting scores, eligibility and decision-time covariates, opening exposure and reconciled outcomes.

Preferred identification: borrower-cluster randomized 90-day holdout, stratified by client, pre-period DPD, risk, geography and exposure. Cluster shared borrowers to prevent cross-account spillovers. Freeze eligibility, prespecify net recovery per opening rupee and cost-adjusted incremental contribution, and measure complaints and opt-outs. Estimate intention-to-treat difference with borrower-cluster bootstrap confidence intervals; size using baseline outcome variance, minimum economically meaningful uplift and 80% power at 5% alpha. Do not invent sample size without those inputs. Preserve outcomes for closed/unreachable accounts; analyze all assigned units.

If only phased observational rollout exists: match/weight on pre-treatment variables and estimate cohort-specific difference-in-differences against not-yet-treated controls. Inspect event-study leads, overlap and balance; avoid a naive two-way fixed-effects estimate under heterogeneous staggered effects. Confounders include client arrivals, DPD aging, staffing/vendor changes, holidays, settlement policy and contact intensity. Parallel trends and no spillovers are substantive assumptions. With universal rollout and no credible control, interrupted time series is descriptive and does not identify targeting lift. Therefore **the no-change recovery total is not estimable from this dataset**.

## 6. ₹10 Cr investment decision

Select borrower targeting for the conditional pilot described in the memo. Telephony needs validated failure causality and cost; staffing needs capacity/paid-hours economics; AI voice needs randomized substitution and quality outcomes; digital needs randomized incremental lift rather than last-touch credit; field needs travel/visit costs and compliant outcomes. None is empirically rankable on net ROI from the supplied tables. Selecting targeting is a hypothesis about allocation efficiency, not proof that these alternatives are inferior.

Base scenario cost envelope: ₹0.5 Cr pilot, ₹2 Cr engineering/data integration, ₹2 Cr experimentation/decision systems, ₹5.5 Cr staged deployment and operating capacity; these are explicit planning assumptions, not vendor quotes. Total ₹10 Cr includes pilot. Evaluate benefits over one prespecified year after deployment, not by annualizing eight observed months. Confirm the 80% retained-contribution assumption with finance. Measure benefit net of displacement across channels and debt vintages. Release remaining funds only if the lower confidence bound on retained benefit exceeds remaining cost and harm metrics meet agreed limits.

## 7. Production analytics architecture

```mermaid
flowchart LR
  A[Immutable raw + ingestion metadata] --> B[Staging: typed timestamps and schema versions]
  B --> C[Clean: deterministic keys + quarantine]
  C --> D[Golden: reconciled ledger + entity history]
  D --> E[Features: pre-treatment account-day]
  E --> F[Versioned metrics + frozen cohorts]
  F --> G[Daily executive dashboard]
  C --> H[Quality alerts and repair queue]
  D --> H
```

Contracts: source event ID, provider transaction ID, operation/state, source timezone, event_at, source_updated_at, ingested_at, schema_version and deletion marker mandatory. Reject unknown schema changes into quarantine. Transaction ledger is keyed by provider + immutable transaction ID + ledger-entry ID; payment reference alone is insufficient. Call and attempt keys remain separate, dispositions reference validated calls. Entity mappings are effective-dated and approved; store unresolved mappings explicitly.

Use bitemporal entity/status history (valid_from/to and system_from/to); never overwrite past cohort features. Keep raw files content-hashed and immutable with run manifest, row counts, schema and source checksums. Golden facts carry source file/row and transformation version. Feature cutoffs prohibit future information. Version metric definitions and expose certified/provisional labels, denominator and data freshness.

Incremental loads: idempotent merge using verified event key plus source version; append corrections and reversal ledger entries. Use source-updated watermark with overlap, e.g. seven days as an initial operational assumption; measure actual lateness and adjust. Rebuild affected event-date partitions for late arrivals; retain as-published snapshots. Controlled backfills use the same code, manifest and before/after reconciliation; never silently change dashboard history.

Checks: uniqueness and not-null critical IDs, FK and account/borrower agreement, timezone parse success, campaign validity, nonnegative amounts, reversal-to-original links, opening + movements = closing balance, source-to-bank cash totals, zero future feature leakage and metric numerator/denominator reconciliation. Critical cash/identity failures block certification; dashboard shows last certified date and provisional amount. Monitor freshness, volume, null rates, conflicts, late-arrival distribution and schema drift by source. Use weekday-aware robust rolling baselines for anomaly alerts once enough history exists; alert on both level and rate, then investigate mix/calendar before declaring an operational incident. Assign data owners and record triage/resolution history.

## Reproducibility and limitations

Run `python solve.py --data <extracted_zip_directory>` with Python 3.11+ and pandas. SQL uses SQLite window functions. Results include payment audit, conservative golden candidate, monthly cash proxies, quality counts, snapshot strata and attribution-window sensitivity. The notebook explains and executes the same pipeline. Assertions verify unique payment IDs, row reconciliation and monthly SUCCESS totals. No external sources or invented data underpin the observed figures.

The results deliberately stop short of a certified recovery rate, channel ROI, agent ranking or causal counterfactual. Those require bank settlement/reversal linkage, repaired entity keys, historical balances/eligibility, trusted timezone/ingestion metadata, dated vendor mappings, cost ledger and randomized rollout records. Providing precise-looking answers without those inputs would defeat the central purpose of the assignment.
