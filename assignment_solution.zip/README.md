# Assignment solution package

Start with SOLUTION.md (full answers) and EXECUTIVE_MEMO.md (short decision memo). Open dashboard.html in a browser. analysis.ipynb is a rerunnable notebook; solve.py and pipeline.sql create the analytical layer.

Install Python 3.11+ and pandas. Extract the supplied ZIP to a data directory, then run:

    python solve.py --data "PATH/TO/DATA" --out results

The notebook defaults to ../work/data; edit DATA for your machine. SQL dialect: SQLite 3 with window functions. Outputs are deterministic under the supplied inputs. The notebook is supplied unexecuted; the underlying pipeline has been run and its reconciliation assertions passed. results contains exact CSVs and a SQLite database with all supplied input tables and analytical views. No bank reconciliation or causal effect is claimed.

This directory is repository-ready; create your Git repository locally if required. No remote repository was created or published. Architecture is included as Mermaid in SOLUTION.md. The original raw CSVs are also embedded in results/analysis.sqlite; avoid redistributing personal data without permission if adapting to a real dataset.
