-- SQLite 3; input tables loaded as text/numeric by solve.py. No arbitrary latest-row selection.
DROP VIEW IF EXISTS monthly_recovery;
DROP VIEW IF EXISTS golden_payments;
DROP VIEW IF EXISTS payment_audit;
DROP VIEW IF EXISTS payment_distinct;
CREATE VIEW payment_distinct AS SELECT DISTINCT * FROM payments;
CREATE VIEW payment_audit AS
WITH id_counts AS (SELECT payment_id,COUNT(*) n FROM payment_distinct GROUP BY payment_id),
ref_counts AS (SELECT provider_id,payment_reference,COUNT(DISTINCT payment_id) n FROM payment_distinct
 WHERE payment_reference IS NOT NULL GROUP BY provider_id,payment_reference),
ranked AS (SELECT p.*,ROW_NUMBER() OVER(PARTITION BY payment_id ORDER BY event_at,amount,payment_status,account_id,borrower_id,payment_reference,provider_id,payment_method) rn FROM payment_distinct p)
SELECT r.*, CASE WHEN i.n>1 THEN 'CONFLICTING_PAYMENT_ID'
 WHEN r.payment_reference IS NULL THEN 'MISSING_REFERENCE'
 WHEN f.n>1 THEN 'PROVIDER_REFERENCE_COLLISION'
 ELSE 'UNIQUE_REFERENCE' END quality_flag
FROM ranked r JOIN id_counts i USING(payment_id)
LEFT JOIN ref_counts f ON r.provider_id=f.provider_id AND r.payment_reference=f.payment_reference WHERE rn=1;
-- Finance-grade certification still requires bank reconciliation and entity repair.
-- This is the conservative reference-safe candidate layer, not audited cash.
CREATE VIEW golden_payments AS SELECT * FROM payment_audit
WHERE quality_flag='UNIQUE_REFERENCE' AND payment_status='SUCCESS' AND amount>0;
CREATE VIEW monthly_recovery AS
WITH raw AS (SELECT substr(event_at,1,7) month,COUNT(*) raw_rows,
 SUM(CASE WHEN payment_status='SUCCESS' THEN amount ELSE 0 END) raw_success FROM payments GROUP BY 1),
clean AS (SELECT substr(event_at,1,7) month,COUNT(*) payment_ids,
 SUM(CASE WHEN payment_status='SUCCESS' THEN amount ELSE 0 END) dedup_success,
 SUM(CASE WHEN payment_status='REVERSED' THEN amount ELSE 0 END) reversed_face_value,
 SUM(CASE WHEN payment_status='SUCCESS' AND quality_flag='UNIQUE_REFERENCE' THEN amount ELSE 0 END) reference_safe_success
 FROM payment_audit GROUP BY 1)
SELECT raw.*,clean.payment_ids,clean.dedup_success,clean.reference_safe_success,clean.reversed_face_value,
 ROUND(clean.dedup_success/30000.0,2) recovery_per_registered_account,
 ROUND(100.0*(clean.dedup_success/LAG(clean.dedup_success) OVER(ORDER BY raw.month)-1),4) provisional_mom_pct
FROM raw JOIN clean USING(month);
