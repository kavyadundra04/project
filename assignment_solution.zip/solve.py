"""Reproduce: python solve.py --data /path/to/extracted/csvs. Python + pandas required."""
from pathlib import Path
import argparse, sqlite3, json, calendar
import pandas as pd

def run(data, out):
 out=Path(out); out.mkdir(parents=True,exist_ok=True)
 tables={f.stem:pd.read_csv(f) for f in Path(data).glob('*.csv') if f.stem!='data_dictionary'}
 con=sqlite3.connect(out/'analysis.sqlite')
 for name,df in tables.items(): df.to_sql(name,con,if_exists='replace',index=False)
 con.executescript((Path(__file__).parent/'pipeline.sql').read_text())
 p=pd.read_sql('select * from payment_audit',con)
 m=pd.read_sql('select * from monthly_recovery',con)
 m.to_csv(out/'monthly_recovery.csv',index=False)
 p.to_csv(out/'payment_audit.csv',index=False)
 pd.read_sql('select * from golden_payments',con).to_csv(out/'golden_payments.csv',index=False)
 issues=[]
 for name,df in tables.items():
  issues.append({'table':name,'raw_rows':len(df),'exact_duplicates':int(df.duplicated().sum()),'null_cells':int(df.isna().sum().sum())})
 pd.DataFrame(issues).to_csv(out/'source_quality.csv',index=False)
 checks={}
 a=tables['accounts']; c=tables['calls'].drop_duplicates('call_id')
 for name in ['payments','calls','call_attempts','call_dispositions','promises_to_pay','whatsapp_events','sms_events','field_visits']:
  d=tables[name]; j=d.merge(a[['account_id','borrower_id']],on='account_id',how='left',suffixes=('','_master'))
  checks[name+'_borrower_mismatch']=int((j.borrower_id!=j.borrower_id_master).sum())
 for name in ['call_attempts','call_dispositions']:
  j=tables[name].merge(c[['call_id','account_id','event_at']],on='call_id',how='left',suffixes=('','_call'))
  checks[name+'_call_account_mismatch']=int((j.account_id!=j.account_id_call).sum())
 ag=tables['agents']; checks['ambiguous_agent_ids']=int((ag.groupby('agent_id').employee_code.nunique()>1).sum())
 checks['borrower_ids_with_multiple_distinct_rows']=int((tables['borrowers'].drop_duplicates().groupby('borrower_id').size()>1).sum())
 h=tables['account_status_history']; checks['history_recorded_before_event']=int((h.recorded_at<h.event_at).sum())
 ca=c.merge(tables['campaigns'][['campaign_id','start_at','end_at']],on='campaign_id',how='left')
 checks['calls_outside_campaign_dates']=int(((ca.event_at<ca.start_at)|(ca.event_at>ca.end_at)).sum())
 checks['event_start']=tables['payments'].event_at.min(); checks['event_end']=tables['payments'].event_at.max()
 checks['payment_flags']=p.groupby('quality_flag').agg(rows=('payment_id','size'),amount=('amount','sum')).reset_index().to_dict('records')
 (out/'forensics.json').write_text(json.dumps(checks,indent=2),encoding='utf8')
 # Descriptive dimensions: snapshot attributes are not historic covariates.
 pay=p[p.payment_status.eq('SUCCESS')].copy(); pay['month']=pay.event_at.str[:7]
 j=pay.merge(a,on='account_id',suffixes=('','_account'))
 for dim in ['loan_type','risk_segment','dpd']:
  j.groupby(['month',dim]).amount.agg(['count','sum']).reset_index().to_csv(out/f'descriptive_{dim}.csv',index=False)
 # Fixed January mix across snapshot risk groups, per registered account (not eligible exposure).
 x=j.groupby(['month','risk_segment']).amount.sum().unstack(fill_value=0)
 n=a.groupby('risk_segment').size(); rates=x.div(n,axis=1)
 weights=n/n.sum(); standardized=rates.mul(weights,axis=1).sum(axis=1)
 standardized.rename('recovery_per_registered_account').to_csv(out/'fixed_snapshot_mix.csv')
 # Account-linked temporal association only, no causal credit. Unknown payment zone assumed IST.
 events=[]
 for name,ch in [('calls','VOICE'),('whatsapp_events','WHATSAPP'),('sms_events','SMS'),('field_visits','FIELD')]:
  d=tables[name].drop_duplicates().copy(); d['channel']=ch
  if name=='calls':
   d['t']=pd.to_datetime(d.event_at)
   offsets={'UTC':5.5,'Asia/Dubai':1.5,'Asia/Kolkata':0}
   d['t']=d['t']+pd.to_timedelta(d.timezone.map(offsets),unit='h')
  else: d['t']=pd.to_datetime(d.event_at)
  events.append(d[['account_id','t','channel']])
 ev=pd.concat(events).sort_values('t'); ev['t']=ev.t.astype('datetime64[ns]'); pp=pay[['payment_id','account_id','event_at','amount']].copy(); pp['t']=pd.to_datetime(pp.event_at).astype('datetime64[ns]')
 rows=[]
 for days in [1,3,7,14]:
  match=pd.merge_asof(pp.sort_values('t'),ev,on='t',by='account_id',direction='backward',tolerance=pd.Timedelta(days=days))
  match['channel']=match.channel.fillna('UNATTRIBUTED')
  z=match.groupby('channel').amount.agg(['count','sum']).reset_index(); z['window_days']=days; rows.append(z)
 pd.concat(rows).to_csv(out/'attribution_sensitivity.csv',index=False)
 assert p.payment_id.is_unique
 assert abs(m.dedup_success.sum()-pay.amount.sum())<.01
 assert len(p)==tables['payments'].payment_id.nunique()
 print(m.to_string(index=False)); print(json.dumps(checks,indent=2))
 con.close()
 return m,checks

if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--data',required=True); ap.add_argument('--out',default=str(Path(__file__).parent/'results')); args=ap.parse_args();run(args.data,args.out)
